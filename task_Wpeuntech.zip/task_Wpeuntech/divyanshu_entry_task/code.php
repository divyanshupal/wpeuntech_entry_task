<?php
$name=$_POST["name"];
$email=$_POST["email"];
$contactno=$_POST["contactno"];
$address=$_POST["address"];
$password=$_POST["password"];
$con=mysqli_connect("localhost","root","","divyanshu_task");
$query="insert into divyanshu_tbl(name,email,contactno,address,password) values('$name','$email','$contactno','$address','$password')";
mysqli_query($con,$query);
echo "<script>alert('Ragistration is done');window.location.href='index.php';</script>";
?>