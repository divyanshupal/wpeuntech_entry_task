-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 05, 2023 at 11:17 AM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `divyanshu_task`
--

-- --------------------------------------------------------

--
-- Table structure for table `divyanshu_tbl`
--

DROP TABLE IF EXISTS `divyanshu_tbl`;
CREATE TABLE IF NOT EXISTS `divyanshu_tbl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contactno` bigint NOT NULL,
  `address` varchar(250) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `divyanshu_tbl`
--

INSERT INTO `divyanshu_tbl` (`id`, `name`, `email`, `contactno`, `address`, `password`) VALUES
(1, 'Divyanshu pal', 'vp3701273@gmail.com', 9026763974, 'RamNagar AmbedkarNagar', '11111'),
(2, 'vishal dubey', 'vishal123@gmail.com', 7054909991, 'Malipur AmbedkarNagar', '123456'),
(3, 'Divyanshu pal', 'vp3701273@gmail.com', 9026763974, '', ''),
(4, 'vipin', 'vipin@gmail.com', 9026763974, 'AmbedkarNagar', '2222'),
(5, 'ww', 'vp3701273@gmail.com', 1111111111, 'aaaaa', '33333');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
